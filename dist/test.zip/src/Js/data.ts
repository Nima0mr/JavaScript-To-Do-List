interface Data {
    id: number;
    selectedId: number;
    toDoArray: any[];
    inputVal: string;
    editInputVal: string;
}

const data: Data = {
    id: 1,
    selectedId: 1,
    toDoArray: [],
    inputVal: '',
    editInputVal: ''
};

